"""DEPRECATED: Kept for backwards compatibility."""

from langchain_core.utils.formatting import StrictFormatter, formatter

__all__ = ["StrictFormatter", "formatter"]
